import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from './components/layout/Layout';
import PortfolioPage from './pages/Portfolio';
import { AssetsPage, AssetDetailPage } from './pages/Assets';
import AcquisitionPage from './pages/Acquisition';
import DealDashboard from './pages/DealDashboard';
import { DevelopmentsPage, DevelopmentDetailPage } from './pages/Developments';
import { SalesPage, SaleDetailPage } from './pages/Sales';
import { MarktPage, DebtPage, CashFlowPage, DocumentsPage, AICopilotPage, NewsPage, DealRadarPage, SettingsPage } from './pages/OtherPages';

export default function App() {
  return (
    <BrowserRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<PortfolioPage />} />
          <Route path="/cashflow" element={<CashFlowPage />} />
          <Route path="/assets" element={<AssetsPage />} />
          <Route path="/assets/:id" element={<AssetDetailPage />} />
          <Route path="/developments" element={<DevelopmentsPage />} />
          <Route path="/developments/:id" element={<DevelopmentDetailPage />} />
          <Route path="/debt" element={<DebtPage />} />
          <Route path="/sales" element={<SalesPage />} />
          <Route path="/sales/:id" element={<SaleDetailPage />} />
          <Route path="/acquisition" element={<AcquisitionPage />} />
          <Route path="/acquisition/:id" element={<DealDashboard />} />
          <Route path="/markt" element={<MarktPage />} />
          <Route path="/documents" element={<DocumentsPage />} />
          <Route path="/ai" element={<AICopilotPage />} />
          <Route path="/radar" element={<DealRadarPage />} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/settings" element={<SettingsPage />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  );
}
