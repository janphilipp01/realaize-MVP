import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Building2, TrendingUp, BarChart3, CreditCard,
  LineChart, FolderOpen, Bot, Settings, ChevronLeft, ChevronRight,
  AlertTriangle, BookUser, HardHat, ShoppingBag, Newspaper, Radar
} from 'lucide-react';
import { useStore } from '../../store/useStore';
import { useLanguage } from '../../i18n/LanguageContext';
import Addressbook from '../Addressbook';

/* ── Flag SVGs ──────────────────────────────────────────── */
function FlagDE({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={Math.round(size * 0.6)} viewBox="0 0 30 18" style={{ borderRadius: 2, overflow: 'hidden', display: 'block' }}>
      <rect width="30" height="6" y="0" fill="#000" />
      <rect width="30" height="6" y="6" fill="#DD0000" />
      <rect width="30" height="6" y="12" fill="#FFCC00" />
    </svg>
  );
}

function FlagEN({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={Math.round(size * 0.6)} viewBox="0 0 30 18" style={{ borderRadius: 2, overflow: 'hidden', display: 'block' }}>
      <rect width="30" height="18" fill="#012169" />
      <path d="M0,0 L30,18 M30,0 L0,18" stroke="#fff" strokeWidth="3" />
      <path d="M0,0 L30,18 M30,0 L0,18" stroke="#C8102E" strokeWidth="1.5" />
      <path d="M15,0 V18 M0,9 H30" stroke="#fff" strokeWidth="5" />
      <path d="M15,0 V18 M0,9 H30" stroke="#C8102E" strokeWidth="3" />
    </svg>
  );
}

/* ── Types ────────────────────────────────────────────── */
interface SubNavItem { key: string; label: string; icon: any; path: string; }
interface NavItem {
  key: string;
  label: string;
  icon: any;
  path: string;
  sub?: SubNavItem[];
}

interface LayoutProps { children: React.ReactNode; }

export default function Layout({ children }: LayoutProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [showAddressbook, setShowAddressbook] = useState(false);
  const location = useLocation();
  const { assets, contacts } = useStore();
  const { lang, toggleLang, t } = useLanguage();

  /* New sidebar order:
     Portfolio (→ Cashflow as sub)
     Assets · Developments · Debt · Sales · Acquisition · Market
     Documents · AI Copilot · Settings
  */
  const NAV_ITEMS: NavItem[] = [
    {
      key: 'portfolio', label: t('nav.portfolio'), icon: LayoutDashboard, path: '/',
      sub: [
        { key: 'cashflow', label: t('nav.cashflow'), icon: LineChart, path: '/cashflow' },
      ],
    },
    { key: 'assets', label: t('nav.assets'), icon: Building2, path: '/assets' },
    { key: 'developments', label: t('nav.developments'), icon: HardHat, path: '/developments' },
    { key: 'debt', label: t('nav.debt'), icon: CreditCard, path: '/debt' },
    { key: 'sales', label: t('nav.sales'), icon: ShoppingBag, path: '/sales' },
    { key: 'acquisition', label: t('nav.acquisition'), icon: TrendingUp, path: '/acquisition' },
    { key: 'radar', label: t('radar.nav'), icon: Radar, path: '/radar' },
    { key: 'markt', label: t('nav.market'), icon: BarChart3, path: '/markt' },
    { key: 'documents', label: t('nav.documents'), icon: FolderOpen, path: '/documents' },
    { key: 'ai', label: t('nav.ai'), icon: Bot, path: '/ai' },
    { key: 'news', label: t('news.nav'), icon: Newspaper, path: '/news' },
    { key: 'settings', label: t('nav.settings'), icon: Settings, path: '/settings' },
  ];

  const breachCount = assets.flatMap(a => a.covenants).filter(c => c.status === 'Breach').length;
  const warningCount = assets.flatMap(a => a.covenants).filter(c => c.status === 'Warning').length;

  const isNavActive = (item: NavItem) => {
    if (item.path === '/') return location.pathname === '/';
    return location.pathname === item.path || location.pathname.startsWith(item.path + '/');
  };
  const isSubActive = (sub: SubNavItem) => location.pathname === sub.path;
  const isParentActive = (item: NavItem) => {
    if (isNavActive(item)) return true;
    return item.sub ? item.sub.some(s => isSubActive(s)) : false;
  };

  return (
    <div className="flex h-full bg-gradient-mesh">
      {/* ═══ Sidebar ═══ */}
      <aside
        className="flex flex-col h-full transition-all duration-300 ease-in-out flex-shrink-0"
        style={{
          width: collapsed ? 60 : 216,
          background: 'rgba(242,242,247,0.88)',
          borderRight: '1px solid rgba(0,0,0,0.06)',
          backdropFilter: 'blur(28px) saturate(1.8)',
          WebkitBackdropFilter: 'blur(28px) saturate(1.8)',
        }}
      >
        {/* Logo + top actions */}
        <div className="flex items-center justify-between px-3 py-4" style={{ borderBottom: '1px solid rgba(0,0,0,0.05)' }}>
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center rounded-xl flex-shrink-0"
              style={{ width: 34, height: 34, background: 'linear-gradient(145deg, #007aff, #0055d4)', boxShadow: '0 2px 10px rgba(0,122,255,0.35)' }}>
              <Building2 size={17} color="#ffffff" strokeWidth={2} />
            </div>
            {!collapsed && (
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: '#1c1c1e', letterSpacing: '-0.03em', lineHeight: 1.2 }}>ReState</div>
                <div style={{ fontSize: 10, color: 'rgba(60,60,67,0.45)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>Investment OS</div>
              </div>
            )}
          </div>
          {/* Addressbook */}
          {!collapsed && (
            <button
              onClick={() => setShowAddressbook(true)}
              title={t('nav.addressbook')}
              style={{
                background: 'rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.07)',
                borderRadius: 9, cursor: 'pointer', padding: '5px 6px',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                position: 'relative',
              }}
            >
              <BookUser size={14} color="rgba(60,60,67,0.65)" />
              {contacts.length > 0 && (
                <span style={{ position: 'absolute', top: -3, right: -3, background: '#007aff', color: '#fff', fontSize: 8, fontWeight: 700, borderRadius: 5, padding: '1px 4px', lineHeight: 1.4 }}>
                  {contacts.length}
                </span>
              )}
            </button>
          )}
        </div>

        {/* ─── Navigation ─── */}
        <nav className="flex-1 px-2 py-3 overflow-y-auto">
          {!collapsed && (
            <div style={{ fontSize: 10, fontWeight: 700, color: 'rgba(60,60,67,0.35)', letterSpacing: '0.06em', textTransform: 'uppercase', padding: '2px 10px 6px' }}>
              {t('nav.navigation')}
            </div>
          )}
          <div className="space-y-0.5">
            {NAV_ITEMS.map(item => {
              const parentActive = isParentActive(item);
              return (
                <div key={item.key}>
                  {/* Main nav link */}
                  <Link
                    to={item.path}
                    className={`nav-item ${parentActive ? 'active' : ''}`}
                    style={collapsed ? { justifyContent: 'center', padding: '9px 0' } : {}}
                  >
                    <item.icon size={15} strokeWidth={parentActive ? 2.5 : 1.8} color={parentActive ? '#007aff' : 'rgba(60,60,67,0.60)'} style={{ flexShrink: 0 }} />
                    {!collapsed && <span>{item.label}</span>}
                    {!collapsed && item.key === 'debt' && (breachCount > 0 || warningCount > 0) && (
                      <span className="ml-auto" style={{ background: '#ff3b30', color: '#fff', fontSize: 10, fontWeight: 700, borderRadius: 10, padding: '1px 6px', lineHeight: 1.6 }}>
                        {breachCount + warningCount}
                      </span>
                    )}
                  </Link>

                  {/* Sub-items (e.g. Cashflow under Portfolio) */}
                  {!collapsed && item.sub && parentActive && (
                    <div style={{ paddingLeft: 22, marginTop: 1, marginBottom: 2 }}>
                      {item.sub.map(sub => {
                        const subAct = isSubActive(sub);
                        return (
                          <Link
                            key={sub.key}
                            to={sub.path}
                            className="nav-item"
                            style={{
                              padding: '6px 10px',
                              fontSize: 12,
                              color: subAct ? '#007aff' : 'rgba(60,60,67,0.55)',
                              fontWeight: subAct ? 600 : 400,
                              background: subAct ? 'rgba(0,122,255,0.08)' : 'transparent',
                              borderRadius: 8,
                              display: 'flex',
                              alignItems: 'center',
                              gap: 8,
                              textDecoration: 'none',
                              transition: 'all 0.15s ease',
                            }}
                          >
                            <sub.icon size={13} strokeWidth={subAct ? 2.5 : 1.8} color={subAct ? '#007aff' : 'rgba(60,60,67,0.50)'} />
                            <span>{sub.label}</span>
                          </Link>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </nav>

        {/* Covenant alert strip */}
        {!collapsed && (breachCount > 0 || warningCount > 0) && (
          <div className="mx-2 mb-2 p-3 rounded-xl" style={{ background: 'rgba(255,59,48,0.08)', border: '1px solid rgba(255,59,48,0.16)' }}>
            <div className="flex items-center gap-2">
              <AlertTriangle size={13} color="#cc1a14" />
              <span style={{ fontSize: 12, color: '#cc1a14', fontWeight: 600 }}>{breachCount} Breach{breachCount !== 1 ? 'es' : ''}</span>
            </div>
            {warningCount > 0 && <div style={{ fontSize: 11, color: 'rgba(60,60,67,0.55)', marginTop: 2 }}>+ {warningCount} Warnings</div>}
          </div>
        )}

        {/* Collapse button */}
        <button onClick={() => setCollapsed(c => !c)}
          className="flex items-center justify-center mx-2 mb-2 p-2 rounded-xl transition-all"
          style={{ background: 'rgba(0,0,0,0.04)', border: '1px solid rgba(0,0,0,0.06)', cursor: 'pointer', color: 'rgba(60,60,67,0.55)', gap: 6 }}>
          {collapsed ? <ChevronRight size={13} /> : <><ChevronLeft size={13} /><span style={{ fontSize: 12, fontWeight: 500 }}>{t('nav.collapse')}</span></>}
        </button>

        {/* User + Language toggle */}
        <div className="flex items-center gap-2 px-3 py-3" style={{ borderTop: '1px solid rgba(0,0,0,0.05)' }}>
          <div className="flex items-center justify-center rounded-full flex-shrink-0"
            style={{ width: 30, height: 30, background: 'linear-gradient(145deg, #007aff, #af52de)', color: '#fff', fontSize: 11, fontWeight: 700 }}>
            MW
          </div>
          {!collapsed && (
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: '#1c1c1e', letterSpacing: '-0.01em' }}>M. Wagner</div>
              <div style={{ fontSize: 11, color: 'rgba(60,60,67,0.45)' }}>Portfolio Manager</div>
            </div>
          )}
          {/* 🌐 Language toggle flag */}
          <button
            onClick={toggleLang}
            title={lang === 'de' ? 'Switch to English' : 'Auf Deutsch wechseln'}
            style={{
              background: 'rgba(0,0,0,0.05)', border: '1px solid rgba(0,0,0,0.07)',
              borderRadius: 8, cursor: 'pointer', padding: '4px 6px',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              transition: 'all 0.2s ease',
              flexShrink: 0,
            }}
            onMouseOver={e => { e.currentTarget.style.background = 'rgba(0,0,0,0.09)'; }}
            onMouseOut={e => { e.currentTarget.style.background = 'rgba(0,0,0,0.05)'; }}
          >
            {lang === 'de' ? <FlagDE size={16} /> : <FlagEN size={16} />}
          </button>
        </div>
      </aside>

      {/* ═══ Main content ═══ */}
      <main className="flex-1 overflow-auto">{children}</main>

      {/* Addressbook slide-over */}
      {showAddressbook && <Addressbook onClose={() => setShowAddressbook(false)} />}
    </div>
  );
}
